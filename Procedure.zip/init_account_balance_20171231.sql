CREATE OR REPLACE PROCEDURE ds.init_account_balance_20171231()
LANGUAGE plpgsql
AS $$
BEGIN
    DELETE FROM DM.DM_ACCOUNT_BALANCE_F WHERE on_date = '2017-12-31';
    
    INSERT INTO DM.DM_ACCOUNT_BALANCE_F
    SELECT
        '2017-12-31' AS on_date,
        b.account_rk,
        b.balance_out,
        b.balance_out * COALESCE(er.reduced_cource, 1) AS balance_out_rub
    FROM DS.FT_BALANCE_F b
    LEFT JOIN DS.MD_ACCOUNT_D a ON 
        a.account_rk = b.account_rk 
        AND a.data_actual_date <= '2017-12-31' 
        AND (a.data_actual_end_date > '2017-12-31' OR a.data_actual_end_date IS NULL)
    LEFT JOIN DS.MD_EXCHANGE_RATE_D er ON 
        er.currency_rk = a.currency_rk 
        AND er.data_actual_date <= '2017-12-31' 
        AND (er.data_actual_end_date > '2017-12-31' OR er.data_actual_end_date IS NULL)
    WHERE b.on_date = '2017-12-31';
END;
$$;