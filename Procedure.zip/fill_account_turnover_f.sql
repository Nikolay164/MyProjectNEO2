CREATE OR REPLACE PROCEDURE ds.fill_account_turnover_f(
    i_OnDate DATE
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_rows_affected INTEGER;
BEGIN
    DELETE FROM DM.DM_ACCOUNT_TURNOVER_F WHERE on_date = i_OnDate;
    GET DIAGNOSTICS v_rows_affected = ROW_COUNT;
    
    INSERT INTO DM.DM_ACCOUNT_TURNOVER_F
    WITH     
    credit_turnover AS (-- Обороты по кредиту 
        SELECT 
            p.credit_account_rk AS account_rk,
            SUM(p.credit_amount) AS credit_amount,
            SUM(p.credit_amount * COALESCE(er.reduced_cource, 1)) AS credit_amount_rub
        FROM DS.FT_POSTING_F p
        LEFT JOIN DS.MD_EXCHANGE_RATE_D er ON 
            er.currency_rk = (SELECT a.currency_rk FROM DS.MD_ACCOUNT_D a WHERE a.account_rk = p.credit_account_rk AND a.data_actual_date <= i_OnDate AND (a.data_actual_end_date > i_OnDate OR a.data_actual_end_date IS NULL))
            AND er.data_actual_date <= i_OnDate 
            AND (er.data_actual_end_date > i_OnDate OR er.data_actual_end_date IS NULL)
        WHERE p.oper_date = i_OnDate
        GROUP BY p.credit_account_rk
    ),  
    debit_turnover AS ( -- Обороты по дебету 
        SELECT 
            p.debet_account_rk AS account_rk,
            SUM(p.debet_amount) AS debet_amount,
            SUM(p.debet_amount * COALESCE(er.reduced_cource, 1)) AS debet_amount_rub
        FROM DS.FT_POSTING_F p
        LEFT JOIN DS.MD_EXCHANGE_RATE_D er ON 
            er.currency_rk = (SELECT a.currency_rk FROM DS.MD_ACCOUNT_D a WHERE a.account_rk = p.debet_account_rk AND a.data_actual_date <= i_OnDate AND (a.data_actual_end_date > i_OnDate OR a.data_actual_end_date IS NULL))
            AND er.data_actual_date <= i_OnDate 
            AND (er.data_actual_end_date > i_OnDate OR er.data_actual_end_date IS NULL)
        WHERE p.oper_date = i_OnDate
        GROUP BY p.debet_account_rk
    ),    
    all_accounts AS (-- Все счета, участвовавшие в проводках
        SELECT DISTINCT account_rk
        FROM (
            SELECT credit_account_rk AS account_rk FROM DS.FT_POSTING_F WHERE oper_date = i_OnDate
            UNION
            SELECT debet_account_rk AS account_rk FROM DS.FT_POSTING_F WHERE oper_date = i_OnDate
        ) t
    )
    SELECT 
        i_OnDate AS on_date,
        a.account_rk,
        COALESCE(ct.credit_amount, 0) AS credit_amount,
        COALESCE(ct.credit_amount_rub, 0) AS credit_amount_rub,
        COALESCE(dt.debet_amount, 0) AS debet_amount,
        COALESCE(dt.debet_amount_rub, 0) AS debet_amount_rub
    FROM all_accounts a
    LEFT JOIN credit_turnover ct ON a.account_rk = ct.account_rk
    LEFT JOIN debit_turnover dt ON a.account_rk = dt.account_rk;
    
    GET DIAGNOSTICS v_rows_affected = ROW_COUNT;
    

END;
$$;