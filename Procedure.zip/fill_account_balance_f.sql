CREATE OR REPLACE PROCEDURE ds.fill_account_balance_f(
    i_OnDate DATE
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_rows_affected INTEGER;
    v_prev_date DATE := i_OnDate - INTERVAL '1 day';
BEGIN
    DELETE FROM DM.DM_ACCOUNT_BALANCE_F WHERE on_date = i_OnDate;
    GET DIAGNOSTICS v_rows_affected = ROW_COUNT;
    
    INSERT INTO DM.DM_ACCOUNT_BALANCE_F
    WITH 
    
    actual_accounts AS (-- Актуальные счета на дату расчета
        SELECT 
            a.account_rk,
            a.currency_rk,
            a.char_type
        FROM DS.MD_ACCOUNT_D a
        WHERE a.data_actual_date <= i_OnDate 
          AND (a.data_actual_end_date > i_OnDate OR a.data_actual_end_date IS NULL)
    ),
    prev_balances AS (   -- Остатки за предыдущий день
        SELECT 
            b.account_rk,
            b.balance_out,
            b.balance_out_rub
        FROM DM.DM_ACCOUNT_BALANCE_F b
        WHERE b.on_date = v_prev_date
    ),
    current_turnovers AS (    -- Обороты за текущий день
        SELECT 
            t.account_rk,
            t.credit_amount,
            t.credit_amount_rub,
            t.debet_amount,
            t.debet_amount_rub
        FROM DM.DM_ACCOUNT_TURNOVER_F t
        WHERE t.on_date = i_OnDate
    ),
    exchange_rates AS (-- Курсы валют на дату расчета
        SELECT 
            er.currency_rk,
            er.reduced_cource
        FROM DS.MD_EXCHANGE_RATE_D er
        WHERE er.data_actual_date <= i_OnDate 
          AND (er.data_actual_end_date > i_OnDate OR er.data_actual_end_date IS NULL)
    )
    SELECT
        i_OnDate AS on_date,
        aa.account_rk,
        CASE 
            WHEN aa.char_type = 'А' THEN 
                COALESCE(pb.balance_out, 0) + COALESCE(ct.debet_amount, 0) - COALESCE(ct.credit_amount, 0)
            WHEN aa.char_type = 'П' THEN 
                COALESCE(pb.balance_out, 0) - COALESCE(ct.debet_amount, 0) + COALESCE(ct.credit_amount, 0)
            ELSE COALESCE(pb.balance_out, 0)
        END AS balance_out,
        CASE 
            WHEN aa.char_type = 'А' THEN 
                COALESCE(pb.balance_out_rub, 0) + COALESCE(ct.debet_amount_rub, 0) - COALESCE(ct.credit_amount_rub, 0)
            WHEN aa.char_type = 'П' THEN 
                COALESCE(pb.balance_out_rub, 0) - COALESCE(ct.debet_amount_rub, 0) + COALESCE(ct.credit_amount_rub, 0)
            ELSE COALESCE(pb.balance_out_rub, 0)
        END AS balance_out_rub
    FROM actual_accounts aa
    LEFT JOIN prev_balances pb ON aa.account_rk = pb.account_rk
    LEFT JOIN current_turnovers ct ON aa.account_rk = ct.account_rk;
    
    GET DIAGNOSTICS v_rows_affected = ROW_COUNT;
    
END;
$$;